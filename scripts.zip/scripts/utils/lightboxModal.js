export function closeLightbox() {
    document.querySelector("#lightbox-modal").style.display = "none";
}